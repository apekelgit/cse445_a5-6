﻿namespace TravelBooking
{
    public static class PasswordUtil
    {
        public static string Hash(string input)
        {
            return input;
        }

        public static bool Verify(string input, string storedHash)
        {
            return storedHash == Hash(input);
        }
    }
}
